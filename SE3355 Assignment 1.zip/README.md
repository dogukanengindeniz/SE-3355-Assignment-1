# SE3355 Assignment - E-Commerce Landing Page

Complete frontend/backend with API and Redux.